package com.example.demo.model.entity;

public class SolutionWithBLOBs extends Solution {
    private String content;

    private String other;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other == null ? null : other.trim();
    }
}