package com.example.demo.model.overview;

public enum ResultCode {
    success,
    fail
}
