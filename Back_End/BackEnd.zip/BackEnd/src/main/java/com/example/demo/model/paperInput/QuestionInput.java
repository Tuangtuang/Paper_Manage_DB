package com.example.demo.model.paperInput;

/**
 * @program: demo
 * @description: 输入题目
 * @author: tyq
 * @create: 2019-05-30 00:39
 **/
public class QuestionInput {
}
